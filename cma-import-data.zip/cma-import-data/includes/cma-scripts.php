<?php

/* Add setting to properties custom post type */
add_action('admin_menu', 'cma_import_submenu_page');
function cma_import_submenu_page() {
  add_submenu_page( 'edit.php?post_type=properties', 'CMA Import', 'Import', 'manage_options', 'properties-import-data', 'cma_import_submenu_page_callback' ); 
}

function cma_import_submenu_page_callback() {
    $data = ( isset($_POST) && $_POST ) ? $_POST : '';
    $res = cma_search_import_data($data);
    $post_ids = ( isset($res['postids']) && $res['postids'] ) ? $res['postids']:'';
    $message = ( isset($res['message']) && $res['message'] ) ? $res['message']:'';
    include('admin-view.php');
}

function cma_search_import_data($data) {
    $result = array();
    $message = '';
    $duplicates = array();
    $itemsImported = array();
    if( $data && array_key_exists( 'cma_search_submit_values', $data) ){
        $csv_file = $_FILES['cma_data_properties'];
        if( ! ( $_FILES['cma_data_properties']['error'] > UPLOAD_ERR_OK ) ){
            $mimes = array('application/vnd.ms-excel','text/csv');
            if( ! in_array($_FILES['cma_data_properties']['type'], $mimes) ){
                $message = 'Invalid file type.';
            } else {
                $csv_to_array = array_map('str_getcsv', file($csv_file['tmp_name']));
                
                foreach ($csv_to_array as $key => $value) {
                  if ($key == 0)
                    continue;
                    
                    // coupon code does not exists
                    if( !check_code_exists( $value[0] ) ) {

                        $my_post = array(
                             'post_title'   => $value[1],                 
                             'post_content' => $value[1],
                             'post_status'  => 'publish',
                             'post_type'    => 'properties',
                          );

                        $post_id = wp_insert_post($my_post);
                        if( $post_id ){
                            cma_update_post_meta( $post_id, 'coupon_code', $value[0] );
                            cma_update_post_meta( $post_id, 'community_name', $value[1] );
                            cma_update_post_meta( $post_id, 'address', $value[3] );
                            cma_update_post_meta( $post_id, 'manager_name', $value[2] );
                            cma_update_post_meta( $post_id, 'manager_email', $value[4] );
                            cma_update_post_meta( $post_id, 'manager_phone', $value[5] );
                            $itemsImported[] = $post_id;
                        }
                    } 
                    else {
                        $duplicates[] = $value[0];
                    }
                    
                } // foreach

                if($duplicates) {
                    $duplicateCount = count($duplicates);
                    $duplicateMsg = ($duplicateCount>1) ? 'Items already exist.':'Item already exists.';
                    $message = 'Import failed. ' . $duplicateMsg;
                } else {
                    $totalItems = ($itemsImported) ? count($itemsImported) : 0;
                    $txt = ($totalItems>1) ? ' items':' item';
                    $message = 'CSV file successfully imported.';
                }
            }
        }
    }

    $response['message'] =  $message;
    $response['postids'] = '';

    if($itemsImported) {
        $response['postids'] = $itemsImported;
        $response['total'] = count($itemsImported);
    } 

    return $response;
}

function cma_search_scripts() {
    // Add Main CSS
    wp_enqueue_style( 'cma-search-main-style', plugins_url() . '/cma-import-data/css/style.css', null, true);
    wp_enqueue_script( 'cma-search-main-script', plugins_url() . '/cma-import-data/js/main.js', array('jquery'), false, true);
}
add_action('wp_enqueue_scripts', 'cma_search_scripts');

function cma_admin_search_scripts(){
    wp_enqueue_style( 'cma-admin-search-main-style', plugins_url() . '/cma-import-data/css/admin-style.css', null, true);
}
add_action( 'admin_enqueue_scripts', 'cma_admin_search_scripts' );


/* Add Properties Custom Post. This function can add multiple custom posts if needed. */
add_action('init', 'cma_cpt_init', 1);
function cma_cpt_init() {
    $post_types = array(
        array(
            'post_type' => 'properties',
            'menu_name' => 'Properties',
            'plural'    => 'Properties',
            'single'    => 'Property',
            'menu_icon' => 'dashicons-admin-multisite',
            'supports'  => array('title','editor','thumbnail')
        )
    );
    
    if($post_types) {
        foreach ($post_types as $p) {
            $p_type = ( isset($p['post_type']) && $p['post_type'] ) ? $p['post_type'] : ""; 
            $single_name = ( isset($p['single']) && $p['single'] ) ? $p['single'] : "Custom Post"; 
            $plural_name = ( isset($p['plural']) && $p['plural'] ) ? $p['plural'] : "Custom Post"; 
            $menu_name = ( isset($p['menu_name']) && $p['menu_name'] ) ? $p['menu_name'] : $p['plural']; 
            $menu_icon = ( isset($p['menu_icon']) && $p['menu_icon'] ) ? $p['menu_icon'] : "dashicons-admin-post"; 
            $supports = ( isset($p['supports']) && $p['supports'] ) ? $p['supports'] : array('title','editor','custom-fields','thumbnail'); 
            $taxonomies = ( isset($p['taxonomies']) && $p['taxonomies'] ) ? $p['taxonomies'] : array(); 
            $parent_item_colon = ( isset($p['parent_item_colon']) && $p['parent_item_colon'] ) ? $p['parent_item_colon'] : ""; 
            $menu_position = ( isset($p['menu_position']) && $p['menu_position'] ) ? $p['menu_position'] : 20; 
            
            if($p_type) {
                
                $labels = array(
                    'name' => _x($plural_name, 'post type general name'),
                    'singular_name' => _x($single_name, 'post type singular name'),
                    'add_new' => _x('Add New', $single_name),
                    'add_new_item' => __('Add New ' . $single_name),
                    'edit_item' => __('Edit ' . $single_name),
                    'new_item' => __('New ' . $single_name),
                    'view_item' => __('View ' . $single_name),
                    'search_items' => __('Search ' . $plural_name),
                    'not_found' =>  __('No ' . $plural_name . ' found'),
                    'not_found_in_trash' => __('No ' . $plural_name . ' found in Trash'), 
                    'parent_item_colon' => $parent_item_colon,
                    'menu_name' => $menu_name
                );
            
            
                $args = array(
                    'labels' => $labels,
                    'public' => true,
                    'publicly_queryable' => true,
                    'show_ui' => true, 
                    'show_in_menu' => true, 
                    'show_in_rest' => true,
                    'query_var' => true,
                    'rewrite' => true,
                    'capability_type' => 'post',
                    'has_archive' => false, 
                    'hierarchical' => false, // 'false' acts like posts 'true' acts like pages
                    'menu_position' => $menu_position,
                    'menu_icon'=> $menu_icon,
                    'supports' => $supports
                ); 
                
                register_post_type($p_type,$args); // name used in query
                
            }
            
        }
    }
}

function cma_display_search_form($atts, $content = null) {

    $a = shortcode_atts( array(
        'perpage' => 20
    ), $atts );

    require_once plugin_dir_path( __FILE__ ) . 'custom-search.php';
    require_once plugin_dir_path( __FILE__ ) . 'search-results.php';

}
add_shortcode('cma-search-form', 'cma_display_search_form');

function cma_update_post_meta( $post_id, $field_name, $value = '' ) {
    if ( empty( $value ) || ! $value )
    {
        delete_post_meta( $post_id, $field_name );
    }
    elseif ( ! get_post_meta( $post_id, $field_name ) )
    {
        add_post_meta( $post_id, $field_name, $value );
    }
    else
    {
        update_post_meta( $post_id, $field_name, $value );
    }
}

function check_code_exists( $coupon_code ) {
    $args = array(
        'post_type'         => 'properties',
        'posts_per_page'    => -1,    
        'meta_query'        => array(
                                array(
                                     'key' => 'coupon_code', 
                                     'value' => $coupon_code,
                                     'compare' => '='
                                 )
        )
    );

    $query = new WP_Query($args);
    return ( $query->have_posts() ) ? true : false;
}


function activate(){ 
    flush_rewrite_rules();
}

function deactivate(){
    flush_rewrite_rules();
}


register_activation_hook( __FILE__, 'activate' );

register_deactivation_hook( __FILE__, 'deactivate' );

