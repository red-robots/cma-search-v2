<?php 
$jsonFilePath = plugins_url('cma-import-data'). '/acf.json';
if ( isset($_GET['downloadjson']) && $_GET['downloadjson'] ) { forceDownLoad($filePath); } ?>
<div class="wrap">
    <h1>Import Data</h1>

    <?php if ($message) { 
        $error_type = ($post_ids) ? 'updated':'error'; ?>
        <div id="message" class="<?php echo $error_type; ?> settings-error notice is-dismissible"><p><strong><?php echo $message; ?></strong></p> <button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
    <?php } ?>


    <p>Use the shortcode <code>[cma-search-form perpage='20']</code> to display the search form.</p>
    <p><a href="<?php echo $jsonFilePath; ?>" download target="_blank">Download this json file</a> and import it to ACF plugin.</p>
    <p style="margin:0 0 0"><strong>Custom Field Names:</strong></p>
    <ul id="acffields">
        <li>coupon_code</li>
        <li>community_name</li>
        <li>address</li>
        <li>manager_name</li>
        <li>manager_email</li>
        <li>manager_phone</li>
    </ul>

    <hr>
    
    <?php /* IMPORT FORM */ ?>
    <form action="" method="post" enctype="multipart/form-data" style="margin:0 0 10px"> 
        <input type="hidden" name="_wp_http_referer" value="<?php echo get_admin_url(); ?>admin.php?page=cma-search-data&message=1">
        <div class="form-input-group">
            <input type="hidden" name="admin_url" id="admin_url" value="<?php echo admin_url('admin-ajax.php'); ?>">
        </div>
        <div class="form-input-group">
            <label for="average_sale" class="text-shadow text-white">Upload File (CSV):</label>
            <input type="file" class="form-input form-editable" name="cma_data_properties" id="cma_data_properties" >
        </div>
        <div class="form-input-group">
            <button type="submit" class="button button-primary" name="cma_search_submit_values">Import Data</button>
            <div class="clear-both"></div>
        </div>    
    </form>
    
    <?php /* RESULTS */ ?>
    <?php if ($post_ids) { 
        $total = count($post_ids);
        $countTxt = ($total > 1) ? $total . ' items': $total . ' item'; 
        ?>
        <div class="count-info"><strong><?php echo $countTxt; ?> imported</strong></div>
        <table class="wp-list-table widefat fixed striped cma-search">
            <thead>
                <tr>
                    <th class="manage-column column-columnname" scope="col">coupon_code</th>
                    <th class="manage-column column-columnname" scope="col">community_name</th>
                    <th class="manage-column column-columnname" scope="col">address</th>
                    <th class="manage-column column-columnname" scope="col">manager_name</th>
                    <th class="manage-column column-columnname" scope="col">manager_email</th>
                    <th class="manage-column column-columnname" scope="col">manager_phone</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach ($post_ids as $postId) { ?>
                <tr>
                    <td><?php echo get_field("coupon_code",$postId); ?></td>
                    <td><?php echo get_the_title($postId); ?></td>
                    <td><?php echo get_field("address",$postId); ?></td>
                    <td><?php echo get_field("manager_name",$postId); ?></td>
                    <td><?php echo get_field("manager_email",$postId); ?></td>
                    <td><?php echo get_field("manager_phone",$postId); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } ?>

</div>